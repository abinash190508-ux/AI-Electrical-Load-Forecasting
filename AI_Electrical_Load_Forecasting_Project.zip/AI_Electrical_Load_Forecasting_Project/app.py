# AI-Based Electrical Load Forecasting System
# Run: streamlit run app.py
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

st.set_page_config(page_title="Electrical Load Forecasting", layout="wide")
st.title("AI-Based Electrical Load Forecasting System")
st.caption("Educational prototype. The included CSV is synthetic sample data, not actual meter readings.")

uploaded = st.file_uploader("Upload CSV with timestamp and load_kW columns", type=["csv"])
if uploaded is None:
    st.info("Upload a dataset, or use the included sample_electricity_load.csv file.")
    st.stop()

data = pd.read_csv(uploaded)
required = {"timestamp", "load_kW"}
if not required.issubset(data.columns):
    st.error("CSV must contain columns named timestamp and load_kW.")
    st.stop()

data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce")
data["load_kW"] = pd.to_numeric(data["load_kW"], errors="coerce")
data = data.dropna(subset=["timestamp", "load_kW"]).sort_values("timestamp")
data = data.drop_duplicates(subset=["timestamp"])
if len(data) < 48:
    st.error("Please upload at least 48 hourly records.")
    st.stop()

# Basic preprocessing and time-based features
data = data.set_index("timestamp").asfreq("h")
data["load_kW"] = data["load_kW"].interpolate(limit_direction="both")
data = data.reset_index()
data["hour"] = data["timestamp"].dt.hour
data["day_of_week"] = data["timestamp"].dt.dayofweek
data["month"] = data["timestamp"].dt.month
data["is_weekend"] = (data["day_of_week"] >= 5).astype(int)
data["lag_1"] = data["load_kW"].shift(1)
data["lag_24"] = data["load_kW"].shift(24)
data["rolling_mean_24"] = data["load_kW"].shift(1).rolling(24).mean()
model_data = data.dropna().copy()

features = ["hour", "day_of_week", "month", "is_weekend", "lag_1", "lag_24", "rolling_mean_24"]
X = model_data[features]
y = model_data["load_kW"]

split = int(len(model_data) * 0.8)
X_train, X_test = X.iloc[:split], X.iloc[split:]
y_train, y_test = y.iloc[:split], y.iloc[split:]
if len(X_test) == 0:
    st.error("Not enough records after preprocessing.")
    st.stop()

model = RandomForestRegressor(n_estimators=150, random_state=42, min_samples_leaf=2)
model.fit(X_train, y_train)
pred = model.predict(X_test)

mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)

c1, c2, c3 = st.columns(3)
c1.metric("MAE (kW)", f"{mae:.3f}")
c2.metric("RMSE (kW)", f"{rmse:.3f}")
c3.metric("R²", f"{r2:.3f}")

st.subheader("Actual vs. Predicted Load — Chronological Test Set")
fig, ax = plt.subplots()
ax.plot(model_data["timestamp"].iloc[split:], y_test.values, label="Actual")
ax.plot(model_data["timestamp"].iloc[split:], pred, label="Predicted")
ax.set_xlabel("Time")
ax.set_ylabel("Load (kW)")
ax.legend()
ax.grid(True, alpha=0.3)
st.pyplot(fig)

st.subheader("Historical Load Profile")
fig2, ax2 = plt.subplots()
ax2.plot(data["timestamp"], data["load_kW"])
ax2.set_xlabel("Time")
ax2.set_ylabel("Load (kW)")
ax2.grid(True, alpha=0.3)
st.pyplot(fig2)

st.subheader("Forecast Next 24 Hours (recursive estimate)")
history = data[["timestamp", "load_kW"]].copy()
future_rows = []
for step in range(24):
    next_time = history["timestamp"].iloc[-1] + pd.Timedelta(hours=1)
    h = next_time.hour
    dow = next_time.dayofweek
    month = next_time.month
    last = history["load_kW"].iloc[-1]
    lag24 = history["load_kW"].iloc[-24] if len(history) >= 24 else last
    roll24 = history["load_kW"].tail(24).mean()
    row = pd.DataFrame([[h, dow, month, int(dow >= 5), last, lag24, roll24]], columns=features)
    forecast = float(model.predict(row)[0])
    future_rows.append((next_time, forecast))
    history = pd.concat([history, pd.DataFrame({"timestamp":[next_time], "load_kW":[forecast]})], ignore_index=True)

future = pd.DataFrame(future_rows, columns=["timestamp", "forecast_load_kW"])
st.dataframe(future, use_container_width=True)
fig3, ax3 = plt.subplots()
ax3.plot(future["timestamp"], future["forecast_load_kW"], marker="o")
ax3.set_xlabel("Time")
ax3.set_ylabel("Forecast load (kW)")
ax3.grid(True, alpha=0.3)
st.pyplot(fig3)

st.download_button("Download 24-hour forecast CSV", future.to_csv(index=False), "load_forecast_next_24_hours.csv", "text/csv")
