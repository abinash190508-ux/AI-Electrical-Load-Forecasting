# AI-Based Electrical Load Forecasting System

## Project
A student prototype that learns hourly electricity-load patterns and estimates future demand using a Random Forest Regressor.

## Included files
- `app.py` — Streamlit dashboard and model pipeline
- `sample_electricity_load.csv` — 90 days of **synthetic sample data** for testing
- `requirements.txt` — Python packages
- `project_report_outline.md` — report structure and explanation

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `streamlit run app.py`
5. Upload `sample_electricity_load.csv` when the app opens.

## Dataset format
CSV columns must be named:
- `timestamp` — date/time such as `2025-01-01 00:00:00`
- `load_kW` — numeric electrical load in kilowatts

Use only public datasets or measurements you are authorized to collect. The bundled dataset is synthetic and should be described as a demo dataset, not real-world meter data.

## Method
1. Parse timestamps and load values.
2. Sort chronologically, remove duplicate timestamps, and interpolate missing hourly load values.
3. Create hour, weekday, month, weekend, previous-hour, previous-day, and rolling-average features.
4. Use the earliest 80% of rows for training and the latest 20% for testing.
5. Train a Random Forest regression model.
6. Evaluate with MAE, RMSE, and R².
7. Display actual/test predictions and a recursive 24-hour forecast.

## Important limitation
This is an educational demonstration. Forecast quality depends on dataset quality, time coverage, and relevant inputs (weather, occupancy, holidays, etc.). Do not claim performance on actual buildings unless tested on authorized real data.
