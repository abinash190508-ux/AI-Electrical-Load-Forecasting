# AI-Based Electrical Load Forecasting System
## Capstone Project Report — Draft

### Abstract
This project presents an AI-based electrical load forecasting system that analyzes historical hourly electricity consumption and predicts future demand. A Random Forest Regression model is trained using time-based features and lagged load values. The system performs data preprocessing, exploratory analysis, chronological model validation, and evaluation using Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and the coefficient of determination (R²). A Streamlit dashboard presents historical load, test-set predictions, and a 24-hour forecast. The supplied dataset is synthetic and is used only to demonstrate the workflow; final results should be recalculated using a permitted public dataset or authorized measurements.

### 1. Introduction
Electricity demand changes over time due to human activity, weather, working schedules, and equipment usage. Forecasting demand supports planning and efficient energy management. Machine learning can identify patterns in historical consumption and estimate future load.

### 2. Problem Statement
To develop a software system that processes historical electricity-load data, learns time-dependent patterns, and forecasts load for a future interval while presenting the results in a user-friendly dashboard.

### 3. Objectives
- Prepare and clean timestamped electrical-load data.
- Examine daily, weekly, and peak-demand patterns.
- Create time and lag features.
- Train a regression model using chronological validation.
- Evaluate the model with MAE, RMSE, and R².
- Display actual and predicted values in a dashboard.

### 4. System Architecture
CSV Dataset → Data Preprocessing → Feature Engineering → Chronological Train/Test Split → Random Forest Regressor → Evaluation Metrics → Streamlit Dashboard → 24-hour Forecast.

### 5. Tools and Technologies
Python, Pandas, NumPy, Matplotlib, Scikit-learn, and Streamlit. Google Colab or Jupyter Notebook may be used for analysis.

### 6. Methodology
The timestamp column is converted to datetime format and load is converted to numeric form. Invalid and duplicate records are removed. Data is sorted by time and missing hourly readings are interpolated. Features include hour, weekday, month, weekend flag, one-hour lag, 24-hour lag, and a rolling 24-hour mean. The data is divided chronologically: the first 80% is used for training and the final 20% for testing. A Random Forest Regressor is trained and evaluated on the later period.

### 7. Evaluation
MAE measures average absolute prediction error. RMSE penalizes larger errors more strongly. R² describes the proportion of variance explained by the model. Record the values shown by the dashboard after running the model on the selected dataset:
- MAE: ______ kW
- RMSE: ______ kW
- R²: ______

Do not fill these values with invented results; use the actual output from your run.

### 8. Results and Discussion
Insert screenshots of the dashboard, historical load profile, actual-versus-predicted graph, and 24-hour forecast. Discuss whether the model follows the major demand patterns and identify periods with larger errors. Results from synthetic data are illustrative and should not be presented as real building performance.

### 9. Limitations
The demonstration does not include weather, occupancy, holidays, or equipment-level information. Synthetic sample data is not representative of a specific building. Recursive forecasts may accumulate error. Model performance may change with season and dataset size.

### 10. Conclusion
The project demonstrates an end-to-end workflow for electrical load forecasting, including data preparation, feature engineering, machine learning, evaluation, and visualization. The dashboard makes it possible to inspect historical load and forecast demand. Future work can use authorized real data, add weather and holiday features, compare several models, and test different forecast horizons.

### References
1. Scikit-learn documentation — Random Forest and regression metrics.
2. Pandas documentation — time-series data handling.
3. Streamlit documentation — dashboard development.
4. Cite the exact source and license of any real dataset used in the final submission.
